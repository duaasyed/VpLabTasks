﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2
{
    class Worker : Human
    {
        private int wage;
        private int hoursWorked;

        public Worker(string firstName, string lastName, int wage, int hoursWorked) : base(firstName, lastName)
        {
            this.wage = wage;
            this.hoursWorked = hoursWorked;
        }

        public int Wage
        {
            get
            {
                return wage;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentException();
                }
                else
                {
                    this.wage = value;
                }
            }
        }

        public int HoursWorked
        {
            get
            {
                return hoursWorked;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }
                else
                {
                    this.hoursWorked = value;
                }
            }
        }

        public double CalculateWage()
        {
            int weeklyHours = (6 * this.hoursWorked);
            double hourlyWage = this.wage / weeklyHours;

            return hourlyWage;
        }
    }
}
