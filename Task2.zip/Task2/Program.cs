﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\n\t\t SYEDA DUAA FATIMA BUKHARI \t\t\n");
            Console.Write("\t\t         01-131182-035 \t\t\n\n");

            List<Worker> worker = new List<Worker>();
            worker.Add(new Worker(" Duaa", "Syed ", 1500, 5));
            worker.Add(new Worker(" Asfa", "Abbasi", 2000, 10));
            worker.Add(new Worker(" Natasha", "Shahid", 1320, 6));
            worker.Add(new Worker(" Sahar", "Khan", 1660, 5));
            worker.Add(new Worker(" Maida", "Afzal", 1950, 5));
            worker.Add(new Worker(" Rauf", "Tiwana", 1370, 8));
            worker.Add(new Worker(" Hayyan", "Khan", 1820, 5));
            worker.Add(new Worker(" Souban", " Abdul Razzaq", 2600, 7));
            worker.Add(new Worker(" Saad", " Iqbal", 1520, 6));
            worker.Add(new Worker(" Shaheer", "Nibbi", 3030, 9));


            Console.WriteLine("\n SORTED LIST \n\n");
            var sortedList = worker.OrderByDescending(w => w.CalculateWage()).ToList();

            foreach (var s in sortedList)
            {
                Console.WriteLine(s.FirstName + " " + s.LastName + " has hourly wage: " + s.CalculateWage());
            }
        }
    }
}
