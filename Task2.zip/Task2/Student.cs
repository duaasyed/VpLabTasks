﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2
{
    class Student : Human
    {
        private int studentID;
        private int marks;
        private string grade;

        public Student(string firstName, string lastName, int sID, string grade, int marks) : base(firstName,lastName)
        {
            this.marks = marks;
            studentID = sID;
            this.grade = grade;
        }

        //properties

        public int StudentID
        {
            get
            {
                return studentID;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentNullException();
                }
                else
                {
                    studentID = value;
                }
            }
        }

        public string Grade
        {
            get
            {
                return grade;

            }
            set
            {
                if(value == null)
                {
                    Console.Write(" You must enter a grade ");

                }
                else
                {
                    grade = value;
                }
            }
        }

        public int Marks
        {
            get
            {
                return marks;

            }
            set
            {
                if (value < 0)
                {
                    Console.Write(" Invalid Input!! ");

                }
                else
                {
                    marks = value;
                }
            }
        }
    }
}
