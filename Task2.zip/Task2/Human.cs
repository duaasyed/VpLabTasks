﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Task2
{
    class Human
    {
        private string firstName;
        private string lastName;

       
        public Human(string fName, string lName)
        {
            firstName = fName;
            lastName = lName;
        }
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                if(value == null)
                {
                    throw new ArgumentNullException(" First name cant be null");
                }
                else
                {
                    firstName = value;

                }
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(" Last name cant be null");
                }
                else
                {
                    lastName = value;

                }
            }
        }

    }
}
