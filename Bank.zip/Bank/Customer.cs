﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    class Customer
    {
        private string customerName;
        public Customer()
        {
            this.customerName = "";
        }
        public Customer(string name)
        {
            customerName = name;
        }
        public string CustomerName
        {
            get
            {
                return customerName;
            }

            set
            {
                customerName = value;
            }
        }

    }
}
