﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    class MortgageAccount : BankAccount
    {
        public MortgageAccount() : base()
        {

        }
        public MortgageAccount(Customer customer, double balance, double interestRate, int monthCount) : base(customer, balance, interestRate, monthCount)
        {

        }
        public override void DepositMoney(double balance)
        {
            Balance = balance;

        }
        public override double CalculateInterest()
        {
            return (InterestRate * Months);
        }
    }
}
