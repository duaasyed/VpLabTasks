﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    class Company : Customer
    {
        public Company() : base()
        {

        }
        public Company(string name) : base(name)
        {

        }
    }
}
