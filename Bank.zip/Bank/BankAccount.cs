﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    abstract class BankAccount
    {
        private Customer customer;
        private double balance;
        private double interestRate;
        private int months;

        protected BankAccount()
        {
            this.customer = new Customer();
            this.balance = this.interestRate = 0f;
        }

        protected BankAccount(Customer customer, double balance, double interestRate, int months)
        {
            this.customer = customer;
            this.balance = balance;
            this.interestRate = interestRate;
            this.Months = months;
        }

        public int Months
        {
            get
            {
                return months;
            }
            set
            {
                months = value;
            }
        }
        public double Balance
        {
            get
            {
                return balance;
            }
            set
            {
                balance = value;
            }
        }
        public double InterestRate
        {
            get
            {
                return interestRate;
            }

            set
            {
                interestRate = value;
            }
        }
        public Customer Customer
        {
            get
            {
                return customer;
            }
            set
            {
                customer = value;
            }
        }
        public abstract void DepositMoney(double balance);
        public abstract double CalculateInterest();
    }
}
