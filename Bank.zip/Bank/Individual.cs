﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    class Individual : Customer
    {
        public Individual() : base()
        {

        }

        public Individual(string name) : base(name)
        {

        }
    }
}
