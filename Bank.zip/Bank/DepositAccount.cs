﻿using System;
using System.Collections.Generic;
using System.Text;

namespace duaa_l4t6
{
    class DepositAccount : BankAccount
    {
        public DepositAccount() : base()
        {

        }
        public DepositAccount(Customer customer, double balance, double interestRate, int monthCount) : base(customer, balance, interestRate, monthCount)
        {

        }
        public override void DepositMoney(double balance)
        {
            Balance = Balance + balance;

        }
        public double getBalance()
        {
            return Balance;
        }
        public override double CalculateInterest()
        {
            if (Balance > 0 && Balance < 1000)
            {
                return 0;
            }
            else
            {
                return (InterestRate * Months);
            }
        }
        public double WithDraw(double amount)
        {
            Balance = Balance - amount;
            return amount;
        }
    }
}
