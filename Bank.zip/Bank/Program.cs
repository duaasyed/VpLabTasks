﻿using System;

namespace duaa_l4t6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\n\t\t    SYEDA DUAA FATIMA BUKHARI \t\t\n");
            Console.Write("\t\t           01-131182-035 \t\t\n\n");

            Customer[] customers = new Customer[]
            {
                new Individual(" Duaa Syed"),
                new Company(" Apple Inc. "),
                new Individual(" Natasha Shahid "),
            };

            LoanAccount[] loanAccounts = new LoanAccount[3];
            DepositAccount[] depositAccounts = new DepositAccount[3];
            MortgageAccount[] mortgageAccounts = new MortgageAccount[3];

            int balance = 3000, months, choice;
            double interestRate = 2.12;
            int exit = 1;
            while (exit != 0)
            {
                Console.Write("\n Enter number of Months: ");
                months = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("\nPress 1 for Loan Account ");
                Console.WriteLine("Press 2 for Deposit Accpunt");
                Console.WriteLine("Press 3 for Mortgage Accpunt ");
                Console.Write("\n\nEnter value of your choice :  ");
                choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        loanAccounts[i] = new LoanAccount(customers[i], balance, interestRate, months);
                        Console.Write(loanAccounts[i].Customer.CustomerName + "'s interest is:  " + loanAccounts[i].CalculateInterest() + " for " + loanAccounts[i].Months + " months\n");
                    }
                }
                else if (choice == 2)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        depositAccounts[i] = new DepositAccount(customers[i], balance, interestRate, months);
                        Console.Write(depositAccounts[i].Customer.CustomerName + "'s interest is:  " + depositAccounts[i].CalculateInterest() + " for " + depositAccounts[i].Months + " months\n");
                    }

                }
                else if (choice == 3)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        mortgageAccounts[i] = new MortgageAccount(customers[i], balance, interestRate, months);
                        Console.Write(mortgageAccounts[i].Customer.CustomerName + "'s interest is:  " + mortgageAccounts[i].CalculateInterest() + " for " + mortgageAccounts[i].Months + " months\n");
                    }
                }
                Console.WriteLine("\nPress (0 to exit/1 to continue): ");
                exit = int.Parse(Console.ReadLine());
                Console.Clear();
            }
        }
    }
}
