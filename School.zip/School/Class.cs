﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School
{
    class Class : School
    {
        private int classID;
        private string department;
        private int totalStudents;

        public Class(string department, int classID, int totalStudents)
        {
            this.department = department;
            this.classID = classID;
            this.totalStudents = totalStudents;
        }

        // properties

        public string Department
        {
            get
            {
                return department;
            }
            set
            {
                department = value;
            }
        }

        public int ClassID
        {
            get
            {
                return classID;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentNullException(" ID can never be null ");
                }
                else
                {
                    classID = value;
                }
            }
        }

        public int TotalStudents
        {
            get
            {
                return totalStudents;
            }
            set
            {
                totalStudents = value;
            }
        }
    }
}
