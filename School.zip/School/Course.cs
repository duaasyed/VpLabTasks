﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School
{
    class Course : Student
    {
        string courseName, preReq;
        int courseID;
        public Course(string registrationNum, string courseName, int courseID, string preReq)
        {
            this.courseName = courseName;
            this.courseID = courseID;
            this.preReq = preReq;
        }

        //properties
         public string CourseName
        {
            get
            {
                return courseName;
            }
            set
            {
                if(value == null)
                {
                    Console.Write(" A course name is required ");
                }
                else
                {
                    courseName = value;
                }
            }
        }

        public int CourseID
        {
            get
            {
                return courseID;
            }

            set
            {
                if(value <= 0)
                {
                    throw new ArgumentNullException(" CourseID can never be null ");
                }
                else
                {
                    courseID = value;
                }
            }
        }

        public string PreReq
        {
            get
            {
                return preReq;
            }
            set
            {
                if(value == null)
                {
                    Console.Write(" PreReq is required ");
                }
                else
                {
                    preReq = value;
                }
            }
        }

    }
}
