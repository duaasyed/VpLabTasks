﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School
{
    class School
    {
        private string name;
        private int totalClasses;
        private int contact;

        public School()
        {
            name = " ";
            totalClasses = 0;
            contact = 0;
        }

        public School(string name, int totalClasses, int contact)
        {
            this.name = name;
            this.totalClasses = totalClasses;
            this.contact = contact;
        }

        //properties

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public int TotalClasses
        {
            get
            {
                return totalClasses;
            }
            set
            {
                totalClasses = value;
            }
        }

        public int Contact
        {
            get
            {
                return contact;
            }
            set
            {
                contact = value;
            }
        }

    }
}
