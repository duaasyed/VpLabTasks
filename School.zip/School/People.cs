﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School
{
    public class People
    {
        private string firstName;
        private string lastName;
        private string occupation;

        public People()
        {
            firstName = lastName = occupation = " ";
        }
        public People(string fName, string lName, string occupation)
        {
            firstName = fName;
            lastName = lName;
            this.occupation = occupation;

        }

        //properties

        public string FirstName
        {
            get
            { 
                return firstName;
            }
            set
            {
                if(value== null)   // value is built in
                {
                    Console.Write("First name can never be Null");
                }
                else
                {
                    this.firstName = value;

                }
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                if (value == null)   // value is built in
                {
                    Console.Write("Last name can never be Null");
                }
                else
                {
                    lastName = value;

                }
            }
        }

        public string Occupation
        {
            get
            {
                return occupation;
            }

            set
            {
                if(value == null)
                {
                    Console.Write(" You must enter an occupation ");
                }
                else
                {
                    occupation = value;
                }
            }
        }

      
    }
}
