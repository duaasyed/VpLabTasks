﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("\n\t\t SYEDA DUAA FATIMA BUKHARI \t\t\n");
            Console.Write("\t\t        01-131182-035 \t\t\n\n");
            Console.Write("\n\t\t PRESENTING THE SORTED LIST \t\t\n\n");

            List<Student> students = new List<Student>();
            students.Add(new Student("Duaa", "Syed", "Student", "A01", 90));
            students.Add(new Student("Natasha", "Shahid", "Student", "A02", 87));
            students.Add(new Student("Asfa", "Abbasi", "Student", "A03", 65));
            students.Add(new Student("Sahar", "Khan", "Student", "A04", 80));
            students.Add(new Student("Shaheer", "Nibbi", "Student", "A05", 93));
            students.Add(new Student("Souban", "Abdul Razzaq", "Student", "A06", 88));
            students.Add(new Student("Rauf", "Tiwana", "Student", "A07", 50));
            students.Add(new Student("Faizan", "Shafique", "Student", "A08", 55));
            students.Add(new Student("Saad", "Iqbal", "Student", "A09", 75));
            students.Add(new Student("Hayyan", "Khan", "Student", "A10", 85));

            students.Sort((x, y) => x.Marks.CompareTo(y.Marks));

            foreach (var s in students)
            {
                Console.WriteLine(" SID: " + s.StudentId + " => " + s.FirstName + " " + s.LastName + " has marks " + s.Marks + ".\n");
            }
        }
    }
}
