﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace School
{
    class Teacher : People
    {
        string id;
        string totalCourses;

        public Teacher(string firstName, string lastName, string occupation, string id)
        {
            this.id = id;
        }

        public string TeacherID
        {
            get
            {
                return id;

            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(" ID cant be null ");
                }
                else
                {
                    id = value;
                }
            }

        }

        public string Courses
        {
            get
            {
                return totalCourses;

            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException(" Courses required ");
                }
                else
                {
                    totalCourses = value;
                }
            }

        }

    }

}
