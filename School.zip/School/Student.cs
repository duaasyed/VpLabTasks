﻿using System;
using System.Collections.Generic;
using System.Text;

namespace School 
{
    class Student : People
    {
        string registrationNum;
        int marks;

        public Student()
        {
            registrationNum = " ";
            marks = 0;
        }
        public Student( string firstName, string lastName, string occupation, string regNum, int marks) : base(firstName,lastName,occupation)
        {
            registrationNum = regNum;
            this.marks = marks;
        }

        public string StudentId
        {
            get
            {
                return registrationNum;
            }
            set
            {
                if(value == null)
                {
                    throw new ArgumentNullException(" Student ID can never be null");
                }
                else
                {
                    registrationNum = value;
                }
            }
        }

        public int Marks
        {
            get
            {
                return marks;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentNullException(" You must enter some marks");
                }
                else
                {
                    marks = value;
                }
            }
        }
    }
}
