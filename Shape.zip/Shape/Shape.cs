﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shape
{
    public abstract class Shape
    {
        private double height;
        private double width;

        public Shape()
        {
            height = width = 0;
        }

        public Shape(double height, double width)
        {
            this.height = height;
            this.width = width;
        }

        //properties

        public double Height
        {
            get
            {
                return this.height;
            }
            set
            {
                if(value <= 0)
                {
                    throw new ArgumentException();
                }
                else
                {
                    height = value;
                }
            }
        }

        public double Width
        {
            get
            {
                return this.width;
            }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException();
                }
                else
                {
                    width = value;
                }
            }
        }

        public abstract double CalculateSurface();
        
    }
}
