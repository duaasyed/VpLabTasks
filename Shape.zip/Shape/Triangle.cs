﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shape
{
    public class Triangle : Shape
    {
        public Triangle() : base()
        {

        }
        public Triangle(double width, double height) : base(width,height)
        {
            
        }
        public override double CalculateSurface()
        {
            double area = Height * Width / 2;
            return area;
        }
    }
}
