﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shape
{
    class Circle : Shape
    {
        private double radius;
        public Circle() : base()
        {

        }
        public Circle(double radius) : base(radius,radius)
        {
            
        }
        public override double CalculateSurface()
        {
            double area = Height * Width * 3.14;
            return area;
        }
    }
}
