﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shape
{
    class Rectangle : Shape
    {
        public Rectangle() : base()
        {

        }
        public Rectangle(double width, double height) : base(width, height)
        {

        }
        public override double CalculateSurface()
        {
            double area = Height * Width;
            return area;
        }
    }
}
