﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Shape
{
    class Program
    {
        static void Main(string[] args)
        { 
            Console.Write("\n\t\t    SYEDA DUAA FATIMA BUKHARI \t\t\n");
            Console.Write("\t\t           01-131182-035 \t\t\n\n");

            {
                Shape[] shapes = new Shape[]
                {
                new Rectangle(8.0,7.5),
                new Circle(16),
                new Triangle(6.5,9.3)
                };
                //storing calculated area in different array.
                double[] areas = new double[3];
                for (int i = 0; i < areas.Length; i++)
                {
                    areas[i] = shapes[i].CalculateSurface();
                }
                var calArea = shapes.Zip(areas, (name, area) => "Class Type ( " + name.GetType().Name + ") || Calculated Area = " + name.CalculateSurface());
                foreach (var a in calArea)
                {

                    Console.WriteLine("-----------------------------------------------------\n");
                    Console.WriteLine(a);
                    Console.WriteLine("-----------------------------------------------------\n");
                }
            }
        }
    }
}
